a = float(input("Сторона квадрата: "))

c = float(input("Висота: "))

print("Площа поверхні:", 2*(a*a + a*c + a*c))
print("Об'єм:", (a*a)*c)